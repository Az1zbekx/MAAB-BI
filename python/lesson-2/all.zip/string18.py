txt = input("Matn kirting: ")
arr = txt.split()
print(f"{arr[0]} bilan boshlanadi\n{arr[-1]} bilan tugaydi")