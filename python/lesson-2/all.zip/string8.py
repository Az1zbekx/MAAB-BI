txt = input("Matn kiriting: ")
print(f"Ushbu satrning 1 - belgisi {txt[0]} oxirgi belgisi {txt[-1]}")