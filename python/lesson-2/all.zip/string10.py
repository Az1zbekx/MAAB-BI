txt = input("Matn kiriting: ")
l = txt.strip().split()
print(f"Ushbu matnda {len(l)} ta so'z bor")