txt = input("Matn kiriting: ")
c = input("Olib tashlanadigan belgi: ")
txt = txt.replace(c, "")
print(f"Belgilar olib tashlandi {txt}")