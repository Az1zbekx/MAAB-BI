txt1 = input("1 - matn: ")
txt2 = input("2 - matn: ")
print(bool(len(txt1) == len(txt2)))
