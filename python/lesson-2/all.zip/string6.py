txt1 = input("1 - matnni kiriting: ")
txt2 = inptu("2 - matnni kiriting: ")
if txt1 in txt2:
    print(f"{txt1} satr {txt2} satrda mavzud")
elif txt2 in txt1:
    print(f"{txt2} satr {txt1} satrda mavzud")
else:
    print("Hech bir satr bir birida mavjud emas")

