txt1 = input("1 - matnni kiriting: ")
txt2 = input("2 - matnni kiriting: ")
if txt1 == txt2:
    print("Ular teng")
else:
    print("Teng emas")