txt = input("Matn kiriting: ")
if txt.isalnum():
    print("Ushbu matnda raqam mavjud")
else:
    print("Ushbu matnda raqam mavjud emas")
