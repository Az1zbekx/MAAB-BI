txt = input("Matn kiriting: ")
print(f"Siz kiritgan matnni teskari varianti {txt[::-1]}")
