txt1 = input("Foydalanuvchi nomini kirting: ")
txt2 = input("Foydalanuvchi parolini kirting: ")
print(bool(len(txt1) != 0 and len(txt2) != 0))