txt = input("Matn kiriting: ")
print(f"Matn uzunligi {len(txt)}\nKatta harfli shakli {txt.upper()}\nKichik harfli shakli {txt.lower()}")
