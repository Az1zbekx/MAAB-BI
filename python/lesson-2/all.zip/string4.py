txt = input("Matn kiriting: ")
if txt == txt[::-1]:
    print("Ushbu matn palindrom")
else:
    print("Ushbu matn palindrom emas")
    