try:
    c = float("Selsiy haroratni kiriting: ")
    f = (c * 9/5) + 32
    print(f"Berilgan selsiy harorat {f} farengeytga teng")
except ValueError:
    print("Xatolik yuz berdi")
