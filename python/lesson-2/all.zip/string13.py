txt = input("Matn kirting: ")
txt = txt.strip()
txt = txt.replace(" ", "")
print(f"Barcha bo'shliqlar olib tashlandi {txt}")