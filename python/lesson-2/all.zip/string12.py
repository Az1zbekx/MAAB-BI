arr = list(map(str, input("So'zlar kiriting: ").split()))
txt = "-".join(arr)
print(f"Natija {txt}")