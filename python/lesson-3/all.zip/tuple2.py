t = (1, 9, 3)
print(max(t))
