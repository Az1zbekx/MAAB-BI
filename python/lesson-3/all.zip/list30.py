lst = [1, 2, 3]
print(lst == sorted(lst))
