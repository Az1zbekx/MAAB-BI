s = {1, 2}
s.add(3)
print(s)
