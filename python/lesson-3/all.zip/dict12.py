d = {'a': 1, 'b': 2, 'c': 1}
print(list(d.values()).count(1))
