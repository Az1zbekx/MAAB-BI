lst = []
print(len(lst) == 0)
