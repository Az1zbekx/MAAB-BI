d = {'a': 1}
d.clear()
print(d)
