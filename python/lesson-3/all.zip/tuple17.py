t = (1, 5, 2, 8, 3)
print(max(t[1:4]))  # subtuple from index 1 to 3
