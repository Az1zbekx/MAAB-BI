lst = [1, 2, 3]
print(lst[0] if lst else None)
