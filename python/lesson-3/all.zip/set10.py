s = set()
print(len(s) == 0)
