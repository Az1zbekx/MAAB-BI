lst = [1, 2, 3, 2]
element = 2
print([i for i, x in enumerate(lst) if x == element])
