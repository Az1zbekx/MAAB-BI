lst = [1, 2, 3]
element = 2
print(element in lst)
