lst = [1, 2, 2, 3]
print(list(set(lst)))
