s = {10, 20, 30}
x = s.pop()
print(x, s)
