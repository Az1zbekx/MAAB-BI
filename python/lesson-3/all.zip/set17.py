s = {1, 2, 3, 4}
odds = {x for x in s if x % 2 == 1}
print(odds)
