d = {}
print(len(d) == 0)
