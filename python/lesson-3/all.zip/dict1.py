d = {'a': 1, 'b': 2}
print(d.get('b', 'Not found'))
