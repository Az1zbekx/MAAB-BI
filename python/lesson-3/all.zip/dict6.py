a = {'x': 1}
b = {'y': 2}
merged = {**a, **b}
print(merged)
