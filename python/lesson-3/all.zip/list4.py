lst = [1, 9, 3]
print(min(lst))
