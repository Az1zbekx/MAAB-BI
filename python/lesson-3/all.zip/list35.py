print(list(range(1, 11)))
