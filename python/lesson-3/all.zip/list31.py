lst = [1, 2]
n = 3
print([x for x in lst for _ in range(n)])
