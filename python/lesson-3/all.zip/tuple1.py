t = (1, 2, 2, 3)
print(t.count(2))
