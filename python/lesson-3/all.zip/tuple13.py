t = (3, 1, 2)
print(sorted(set(t))[1])
