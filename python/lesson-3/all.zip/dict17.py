d = {'a': {'x': 10}, 'b': 2}
print(d['a'].get('x'))
