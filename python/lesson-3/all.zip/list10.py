lst = [3, 1, 2]
print(sorted(lst))
