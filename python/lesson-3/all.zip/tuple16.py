t = (1, 2, 3)
print(t == tuple(sorted(t)))
