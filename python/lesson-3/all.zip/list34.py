lst = [1, 2, 3, 4]
k = 1
print(lst[-k:] + lst[:-k])
