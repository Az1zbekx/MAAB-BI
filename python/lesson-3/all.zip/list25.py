lst = [1, 2, 3]
copy_lst = lst[:]
print(copy_lst)
