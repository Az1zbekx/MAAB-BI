d = {'a': 1, 'b': 2, 'c': 1}
print(len(set(d.values())))
