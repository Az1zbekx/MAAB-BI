s = {1, 5, 3}
print(max(s))
