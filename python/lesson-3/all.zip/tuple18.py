t = (1, 5, 2, 8, 3)
print(min(t[1:4]))
