d = {'a': 1, 'b': 2}
d.pop('b', None)
print(d)
