lst = [1, 2, 3]
lst.insert(1, 99)
print(lst)
