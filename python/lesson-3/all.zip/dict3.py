d = {'a': 1, 'b': 2}
print(len(d))
