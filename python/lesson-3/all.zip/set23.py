import random
s = set(random.sample(range(1, 100), 5)) 
print(s)
