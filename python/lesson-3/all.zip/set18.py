s = set(range(1, 11))
print(s)
