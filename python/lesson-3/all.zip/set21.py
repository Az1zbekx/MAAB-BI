lst = [1, 2, 2, 3]
unique = list(set(lst))
print(unique)
