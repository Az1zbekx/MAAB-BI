single = (42,)
print(single)
