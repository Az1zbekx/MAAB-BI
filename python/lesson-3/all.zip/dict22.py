d = {'a': 1, 'b': 5, 'c': 3}
filtered = {k: v for k, v in d.items() if v > 2}
print(filtered)
