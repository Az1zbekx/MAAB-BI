a = {1, 2}
b = {1, 2, 3}
print(a.issubset(b))
