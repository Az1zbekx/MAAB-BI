s = {1, 2, 3, 4}
evens = {x for x in s if x % 2 == 0}
print(evens)
