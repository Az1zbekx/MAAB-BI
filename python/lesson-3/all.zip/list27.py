lst = [1, 5, 2, 8, 3]
print(max(lst[1:4]))  # example sublist from index 1 to 3
