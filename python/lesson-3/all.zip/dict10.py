d = {'a': 1, 'b': 2}
key = 'a'
if key in d:
    print((key, d[key]))
