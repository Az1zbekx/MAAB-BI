a = [1, 2, 2]
b = [2, 3, 4]
merged = set(a + b)
print(merged)
