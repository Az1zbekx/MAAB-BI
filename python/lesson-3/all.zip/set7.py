lst = [1, 2, 2, 3]
s = set(lst)
print(s)
