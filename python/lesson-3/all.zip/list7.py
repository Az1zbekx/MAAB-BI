lst = [1, 2, 3]
print(lst[-1] if lst else None)
