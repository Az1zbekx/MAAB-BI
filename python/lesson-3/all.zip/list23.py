lst = [1, 2, 3, 4]
print([x for x in lst if x % 2 == 1])
