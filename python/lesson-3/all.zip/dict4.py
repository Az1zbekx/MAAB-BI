d = {'a': 1, 'b': 2}
print(list(d.keys()))
