s = {1, 2, 3}
s.discard(2)
print(s)
