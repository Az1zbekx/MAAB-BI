t = (1, 2, 3)
print(t[0] if t else None)
