lst = [1, 2, 3, 2]
element = 2
print(lst.index(element))
