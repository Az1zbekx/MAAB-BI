s = {1, 2, 2, 3}
print(len(s))
