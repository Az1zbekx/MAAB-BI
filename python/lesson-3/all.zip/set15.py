s = {1, 5, 3}
print(min(s))
