t = (1, 2, 3)
print(t[-1] if t else None)
