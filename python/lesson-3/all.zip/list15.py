lst = [1, 2, 4, 5]
print(len([x for x in lst if x % 2 == 0]))
