t = (1, 2, 3)
print(2 in t)
