t = (('a', 1), ('b', 2))
d = dict(t)
print(d)
