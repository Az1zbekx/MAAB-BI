d = {'a': 1}
d['a'] = 99
print(d)
