r = tuple(range(1, 11))
print(r)
