lst = [1, 3, 2]
print(sorted(set(lst))[-2])
