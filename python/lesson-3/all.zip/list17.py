a = [1, 2]
b = [3, 4]
print(a + b)
