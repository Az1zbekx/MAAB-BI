lst = [1, 2, 3]
print(lst[::-1])
