d = {'a': 1, 'b': 2}
first = next(iter(d.items()))
print(first)
