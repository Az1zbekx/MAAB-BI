lst = [1, 2, 2, 3]
element = 2
print(lst.count(element))
