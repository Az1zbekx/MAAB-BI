lst = [1, 2, 3]
index = 1
if 0 <= index < len(lst):
    del lst[index]
print(lst)
