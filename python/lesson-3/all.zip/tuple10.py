t = ()
print(len(t) == 0)
