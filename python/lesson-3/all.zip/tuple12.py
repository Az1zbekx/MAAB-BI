t = (1, 3, 2, 3)
print(sorted(set(t))[-2])
