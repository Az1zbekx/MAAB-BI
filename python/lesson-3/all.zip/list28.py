lst = [1, 5, 2, 8, 3]
print(min(lst[1:4]))
