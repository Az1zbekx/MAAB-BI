keys = ['a', 'b']
values = [1, 2]
d = dict(zip(keys, values))
print(d)
