a = [3, 1]
b = [2, 4]
print(sorted(a + b))
