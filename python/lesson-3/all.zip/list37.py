lst = [-1, 2, 3, -4]
print(sum(x for x in lst if x < 0))
