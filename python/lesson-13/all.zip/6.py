import numpy as np
arr = np.random.rand(30)
print(arr)
print(np.mean(arr))