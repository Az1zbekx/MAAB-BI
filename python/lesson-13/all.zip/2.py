import numpy as np
arr = np.arange(0, 9)
arr = arr.reshape(3, 3)
print(arr)