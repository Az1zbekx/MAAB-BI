import numpy as np
a = np.random.rand(3, 3)
print(np.linalg.det(a))