import numpy as np
arr = np.random.rand(10, 10)
print(arr)
print(np.min(arr), np.max(arr))