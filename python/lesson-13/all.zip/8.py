import numpy as np
a = np.random.rand(5, 3)
b = np.random.rand(3, 2)
print(np.dot(a, b))