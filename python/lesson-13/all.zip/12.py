import numpy as np
a = np.random.rand(3, 4)
b = np.random.rand(4, 3)
print(np.dot(a, b))
