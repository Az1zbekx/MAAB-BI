import numpy as np
arr = np.arange(10, 50)
print(arr)