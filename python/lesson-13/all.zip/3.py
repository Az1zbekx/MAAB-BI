import numpy as np
arr = np.eye(3)
print(arr)