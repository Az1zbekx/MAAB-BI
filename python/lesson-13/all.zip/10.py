import numpy as np
a = np.random.rand(4, 4)
print(np.transpose(a))