import numpy as np
arr = np.random.rand(3, 3, 3)
print(arr)