import numpy as np
arr = np.random.rand(5, 5)
print(np.sum(arr, axis = 1), np.sum(arr, axis = 0))

