try:
    n = int(input())
    for i in range(1, n):
        print(i ** 2)
except ValueError:
    print("Error")